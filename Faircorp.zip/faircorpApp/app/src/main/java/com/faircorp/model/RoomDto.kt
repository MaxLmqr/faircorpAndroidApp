package com.faircorp.model

class RoomDto(val id: Long,
              val name: String,
              val currentTemperature: Double?,
              val targetTemperature: Double?) {

}