package com.faircorp.model

class HeaterDto {
}